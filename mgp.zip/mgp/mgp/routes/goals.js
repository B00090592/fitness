var express = require('express');
var router = express.Router();
var fs = require('fs');
var mysql = require('mysql');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('goals', { title: 'Express' });
});


var con = mysql.createConnection({

  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'test'

});





/*
router.get('/', function(request, response){
  var result;
  fs.readFile('goals.ejs', 'utf8', function(error, data){

    con.query('SELECT * FROM cal', function(error, results){
      result = results;
      response.render(__dirname + '/goals', {data: results} );
      console.log("Query results(inside): " + JSON.stringify(results));
    });
    console.log("Query results(outside): " + JSON.stringify(results));


  });
});
*/





module.exports = router;




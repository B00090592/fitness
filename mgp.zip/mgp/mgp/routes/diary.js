var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('diary', { title: 'Express' });
});

/*
app.post('/populateCalorieTable', (req, res, next) => {
  var food = req.body.breakfast;
  var foodAmount = req.body.breakfastweight;
  console.log("TEST"+food);
  console.log("TEST"+foodAmount);


  function myFunction() {
    var table = document.getElementById("myTable");
    var row = table.insertRow(0);
    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    cell1.innerHTML = food;
    cell2.innerHTML = cals;
  }
});

*/

module.exports = router;

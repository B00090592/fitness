// creating servers
// practising in different por
var http = require("http");
var express = require("express");
var bodyParser = require('body-parser');
var mysql = require("mysql");
var app = express();

var connection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : '',
    database : 'test'
});

connection.connect(function (err) {
    if(err) throw err;

        console.log('You are now Connected!!!')



});

app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
    extended: true
}));


app.get('/help', function(req, res, next) {
    res.render('help');
});



connection.connect(function(err , connection){

    app.post('/myaction', function(req,res){

        console.log(req.body)

    })
});




//listen to port
app.listen(5000);
console.log('you are listening to port 5000');



/*
var server = app.listen(3000, "127.0.0.1", function () {

    var host = server.address().address;
    var port = server.address().port;

    console.log("Example app listening at http://%s:%s", host, port)

});

*/








/*

//rest api to get all results
app.get('/help', function (req, res) {

    console.log(req);

    connection.query('select * from example', function (error, results, fields) {
        if (error) throw error;


        res.end(JSON.stringify(results));



    });


});
 */






/*rsr

//rest api to get a single employee data
app.get('/help/:id', function (req, res) {
    connection.query('select * from example where id=1', [req.params.id], function (error, results, fields) {
        if (error) throw error;
        res.end(JSON.stringify(results));


    });
});

//rest api to create a new record into mysql database
app.post('/help', function (req, res) {
    var postData  = req.body;
    connection.query('INSERT INTO example SET ?', postData, function (error, results, fields) {
        if (error) throw error;
        res.end(JSON.stringify(results));
    });
});

/*
//rest api to update record into mysql database
app.put('/help', function (req, res) {
    connection.query('UPDATE `employee` SET `employee_name`=?,`employee_salary`=?,`employee_age`=? where `id`=?', [req.body.employee_name,req.body.employee_salary, req.body.employee_age, req.body.id], function (error, results, fields) {
        if (error) throw error;
        res.end(JSON.stringify(results));
    });
});
*/


/*
//rest api to delete record from mysql database
app.delete('/help', function (req, res) {
    console.log(req.body);
    connection.query('DELETE FROM `example` WHERE `id`=4', [req.body.id], function (error, results, fields) {
        if (error) throw error;
        res.end('Record has been deleted!');
    });
});

var session = require('express-session');
app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}));


*/




////////////////////////////////////////////////////////////////////
/*
var pool  = mysql.createPool({
    connectionLimit : 10,
    host            : 'localhost',
    user            : 'user_name',
    password        : 'password',
    database        : 'db_name'
});
pool.query("INSERT INTO cal (no, name, place) VALUES ('1','Tom','NW')",function(err, result)
{
    if (err)
        throw err;
});

*/


////////////////////////////////////////////////////////////

/*
app.get("/help", function (req, res) {
    res.render('conor');

});
//connection.end();


app.set('view engine','ejs');

//set up templates

//static files
app.use(express.static('./views'));

*/

















/*
//listen to port
app.listen(5000);
console.log('you are listening to port 5000');
*/


/*
var connection = mysql.createConnection({
    host : "localhost",
    user : "root",
    password : "",
    database : "test"
});

connection.connect();

app.get("/help",function  (req,res) {

    connection.query('SELECT * from orders2', function (err, res, next) {
        if (err) throw err;

        console.log(res);

    });

    console.log(connection);
    res.render('help');
    console.log('connection was made');
    var strings =["rad","bla","conor"];
    console.log(strings);

});
 */









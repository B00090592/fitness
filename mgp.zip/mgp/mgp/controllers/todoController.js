var bodyParser = require('body-parser');

var data = [{item:'cycle'}, {item:'Run'}, {item:'row'}];
var urlencodedParser = bodyParser.urlencoded({extended: false});




module.exports = function (app1) {

    app1.get('/todo',function (req, res) {
        res.render('todo',{todos: data});

    });


    app1.post('/todo', urlencodedParser, function (req, res) {
        data.push(req.body);

        //data.push(req.body);
        res.json(data);

    });

    app1.delete('/todo/item',function (req, res) {

    });
};

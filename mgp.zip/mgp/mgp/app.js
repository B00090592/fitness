var createError = require('http-errors');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var mysql = require('mysql');


var express = require('express');
//var bodyParser = require('body-parser');
var app = express();




//app.use(bodyParser.urlencoded({extended: false}));
//app.use(bodyParser.json());





//element.on('click', function(){})

//practising JSON actions
var stuff = require('./stuff');

console.log(stuff.counter(['shaun','crystal','ryu']));
console.log(stuff.adder(5,6));
console.log(stuff.adder(stuff.pi,5));


// This is for the route pages
var indexRouter = require('./routes/index');
var goals = require('./routes/goals');
var diary = require('./routes/diary');
var nutrition = require('./routes/nutrition');

//Login Page
var login = require('./routes/login');
var register = require('./routes/register');

//Accounts
var student = require('./routes/student');
var admin = require('./routes/admin');
//food diary

var fooddiary = require('./routes/fooddiary')

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'views')));


// home pages


app.use('/', indexRouter);

app.use('/goals', goals);

app.use('/diary', diary);

app.use('/nutrition', nutrition);

app.use('/login', login);

app.use('/register', register);
//Accounts
app.use('/student',student);
app.use('/admin',admin);

app.use('/fooddiary',fooddiary);


///////////////////////////////
//Database Connection
//////////////////////////////

  var con = mysql.createConnection({

  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'test'

});

con.connect(function(err) {
  if (err) throw err;
  con.query("SELECT * FROM cal", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
  });
});



  ///food calculator

app.post('/populateCalorieTable', (req, res, next) => {
  var food = req.body.breakfast;
  var foodAmount = req.body.breakfastweight;
  var result = [];
  console.log("TEST"+food);
  console.log("TEST"+foodAmount);
  con.query("SELECT * FROM foodcalories WHERE foodName ='"+food+"'", (err, rows) => {
    if (err) throw err;
    var foodtotal = foodAmount * rows[0].calsPerGram;
    console.log('row is:', rows[0].calsPerGram);
    console.log('Answer is: ' +foodtotal+' calories');

    var sum = foodtotal;





    //  if(rows.length){
//   for(var i = 0; i<rows.length; i++ ){
//                   result.push(Object.assign({}, i));
//                   console.log('RESULT', result[1]);
//       }
//    }
    //console.log('CALCULATE TEST', foodcalories);
  })
});


app.locals.myVar = 1;


app.get('/', function(req, res) {
  res.render('goals');
});

////////////////////////////////////
//Login Connection
/////////////////////////////////////
/////////////////////////////////////////////
//the post that connection to the login page
/////////////////////////////////////////////

var data =[{item:'luca'}];

app.post('/login', function (req, res) {




  var un = req.body.username;
  var pw = req.body.password;

  console.log(data);
  console.log(un);
  console.log(pw);

con.query("select * from groupinfo where username = '"+un+"' and password='"+pw+"'", function (err, results){

	if (err) console.log(err);
	console.log("login post Error");

  if(results.length ===1){
    res.send(un);
  }else{
    res.send("0");
  }
});
});

//////////////////////////////////////////////////////////
//calculations post for exercises
///////////////////////////////////////////////////////
app.post('/calculate', function (req, res, next) {

  var id = req.body.number;
  var min = req.body.workmin;
  var act = req.body.active;

  var result = [];
  //simply outputs to the console
  console.log("example" + id);
  console.log("example" + min);
  console.log("example" + act);


  con.query("Select * FROM cal WHERE exercise = '"+act+"'", function (err,rows, results) {
    if(err) throw err;

    var totalCalories = min * rows[0].caloriesperminute;
    console.log('row is ', rows[0].caloriesperminute);
    console.log('Answer is , '+totalCalories+' calories');

    let sum = totalCalories();
     console.log(sum);

  });
});


app.locals.myVar = 1;


app.get('/', function(req, res) {
  res.render('goals');
});

//simply send data using the sand technique as long in
// This is called when button is clicked in goals.ejs

app.post('/send', function (req, res) {

  var ex = req.body.exercise;
  var re = req.body.reps;
  var mi = req.body.minutes;

  //simply outputs to the console
  console.log(ex);
  console.log(re);
  console.log(mi);

  con.query("INSERT INTO cal(id,exercise,caloriesperminute) values('+ex+' , '" + re + "','" + mi + "')", function (err, results) {

    if (err) console.log(err);
    console.log("login post Error");

    if (results.length === 1) {
      res.send(ex);

    } else {
      res.send("0");
    }
  });



app.listen(3000);












///////////////////////////////////////////////////////////////////////////////////
  con.query("SELECT COUNT(*) AS count FROM  cal", (err, rows)=>{
    const  count= rows[0].count;

    console.log(`count: ${count}`);

    console.log(`${count}*${count}`);



  });
// end of function for table

var someVar = [];

con.query("select * from cal",function (err,rows) {
  if(err){
    throw  err;
  }else{
    setValue(rows);
  }

  });

function setValue(value) {
  someVar = value;
  console.log("hello someVar" +someVar);

}

  //var adding = con.query("select calsperminute, FROM cal WHERE calsperminute = 3")
});


app.get('/goals', function(req, res){
  console.log(req);

  con.query('select * from cal', function (error,results,fields) {
    if(error) throw error;
    res.end(JSON.stringify(results));


  });
});

/*
var obj = {};
app.get('/goals', function (req,res) {

  con.query("SELECT * FROM cal",function (err,result){
    if(err){
      throw  err;
    }else{
      obj = {print: result};
      res.render('print',obj);

    }

  });


});
*/

////////////////////////////
//register query
////////////////////////////
app.post('/register', function (req, res) {

console.log(req.body.username);
console.log(req.body.password);


con.query("INSERT INTO `groupinfo`(`username`,`password`) VALUES ('"+req.body.username+"','"+req.body.exercise+"')", function (err, results){
    
	if (err) console.log(err);
    console.log("hello");

});

});


// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;

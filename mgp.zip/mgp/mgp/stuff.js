
// running with json
var counter = function(arr){
    return 'There are' + arr.length + 'elements in this array';

};

var adder = function(a,b){
    return `The Sum of the 2 numbers is ${a+b}`;
};
var pi = 3.142;



module.exports = {
    counter: counter,
    adder: adder,
    pi:pi
};
//module.exports.counter = counter;// allows the whole app to access var counter
//module.exports.adder = adder;
//module.exports.pi = pi;


// module.exports.counter  can be declare like this but better the other way

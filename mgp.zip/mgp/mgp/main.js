// creating servers
// practising in different por
var express = require('express');
var todoControllers = require('./controllers/todoController');

var app1 = express();


app1.set('view engine','ejs');

//set up templates

//static files
app1.use(express.static('./public'));


//fire controllers
todoControllers(app1);
//listen to port
app1.listen(4000);
console.log('you are listening to port 4000');


















// this is for makeing different pages and data
//  By following the tutorial
/*
var express = require('express');
var bodyParser = require('body-parser');

var app1 = express();
var urlencodedParser = bodyParser.urlencoded({extended: false});





app1.set('view engine', 'ejs');


//app1.use('/public', express.static('stylesheets'));


//app1.get('/', function(req, res){
   res.render('index1');
});
// get the information for the contact form
app1.get('/contact', function(req, res){
   res.render('contact',{qs: req.query});// adding the url query to the view
});

//posts the information submitted to the console
app1.post('/contact', urlencodedParser, function(req, res){
   console.log(req.body);
   res.render('contact-success',{data: req.body});// adding the url query to the view
});

//rendering different profiles
// this is and idea for making two user / admin pages fro the project
app1.get('/profile/:name',function (req, res){
   var data ={ age:22, job:'Bartender', hobbies:['eating','fighting','fishing']};
   res.render('profile', { person: req.params.name, data: data});
});

app1.listen(4000);
*/
/*
var http = require('http');
var fs = require('fs');

// using pipes to load a particular files
// this renders a html file to the port located further
var server = http.createServer(function(req,res){

    console.log('request was made:' + req.url);
    if(req.url ==='/home' || req.url === '/'){

       res.writeHead(200,{'content-Type': 'text/html'});
       fs.createReadStream(__dirname + '/index.html').pipe(res);

    }else if (req.url ==='/contact-us'){

       res.writeHead(200,{'content-Type': 'text/html'});
       fs.createReadStream(__dirname + '/contact.html').pipe(res);

    } else if (req.url === '/api/ninjas'){
       var ninjas = [{name: 'Conor', age:29}, {name:'mario',age:32}];

       res.writeHead(200,{'Content-Type': 'application/json'});
       res.end(JSON.stringify(ninjas));
    }else{

       res.writeHead(200,{'content-Type': 'text/html'});
       fs.createReadStream(__dirname + '/404.html').pipe(res);

    }

});

// starts on port 4000/ on ip 127.0.0.1
server.listen(4000,'127.0.0.1');
console.log('yo dawgs, now listening to port 4000');


*/
// this passes json DATA
/*
    res.writeHead(200, {'content-Type': 'application/json'}); // change from plain to html//
   // This is for rendering html files(text/html)

   //res.end('feed me popcorn');

   // this passes a json file to the client side
   var myObj = {

      name: 'Conor',
      job: 'Bartender',
      age: 29

   };
   res.end(JSON.stringify(myObj));
*/





/* this is the pipe to render the index.html file
var myReadStream = fs.createReadStream(__dirname + '/index.html', 'utf8');
    myReadStream.pipe(res);
 */
/*
myReadStream.on('data', function(chunk){
   console.log('new chunk received');
   myWriteStream.write(chunk);
});
*/